
module.exports = {
  siteUrl: "https://thecapitalacademy.online",
  generateRobotsTxt: true,
}