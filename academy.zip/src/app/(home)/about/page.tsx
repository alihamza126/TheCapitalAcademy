import AboutPage from "./About";

export const metadata = {
  title: "About Us",
  description: `Learn more about our mission and vision.`,
  
};

const page = () => {
  return (
    <AboutPage/>
  )
}

export default page