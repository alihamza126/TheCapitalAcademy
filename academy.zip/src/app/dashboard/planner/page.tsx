import StudyPlanner from '@/components/dashboard/planner/study-planner'
import React from 'react'

const page = () => {
  return (
    <div>
      <StudyPlanner />
    </div>
  )
}

export default page