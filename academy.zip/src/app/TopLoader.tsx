"use client"
import NextTopLoader from 'nextjs-toploader';

const TopLoader = () => {
    return (
        <NextTopLoader showSpinner={false} />
    )
}

export default TopLoader